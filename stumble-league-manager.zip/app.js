// App scaffold
console.log('Stumble League Manager');